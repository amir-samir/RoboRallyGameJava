package game.Board;


public class RestartPoint extends BoardElement {

    public RestartPoint(){
        this.setType("RestartPoint");
    }

    @Override
    public void effect(){

    }
}

