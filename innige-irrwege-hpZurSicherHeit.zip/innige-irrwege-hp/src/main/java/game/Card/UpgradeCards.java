package game.Card;

//Es gibt insgesamt 5 verschiedene Arten von Cards.UpgradeCards
public abstract class UpgradeCards extends Cards {
    private String name ;
    private String description;
    private Integer cost;
}
