package game.Card;

public class VirusCard extends DamageCards {
    @Override
    public void effect() {

    }
}
