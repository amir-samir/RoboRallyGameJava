package game.Card;

public class Trojan extends DamageCards{
    @Override
    public void effect() {

    }
}
