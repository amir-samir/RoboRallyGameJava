package game.Card;

public class Worm extends DamageCards{
    @Override
    public void effect() {

    }
}
