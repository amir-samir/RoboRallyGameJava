package game.Card;

public class Spam extends DamageCards{
    @Override
    public void effect() {

    }
}
