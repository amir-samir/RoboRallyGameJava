package Messages;

public class CurrentCardObject {

    int clientID;
    String card;

    public CurrentCardObject(int id, String card){
        this.clientID = id;
        this.card = card;
    }
}
