package Messages;

public class Alive extends Message {

    public Alive(){
        super();
        messageType = "Alive";
        messageBody = null;
    }

}
