public class VirusCard extends DamageCards {
    @Override
    public void effect(Robot robot, Server server) {

    }
}
