public class AgainCard extends Cards {

    public AgainCard(){
        this.setName("Again");
    }

    @Override
    public void effect(Robot robot, Server server){
    }

}
