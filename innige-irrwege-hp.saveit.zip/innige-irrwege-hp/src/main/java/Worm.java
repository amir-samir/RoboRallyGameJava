public class Worm extends DamageCards{
    String name = "WORM";
    @Override
    public void effect(Robot robot, Server server) {
      //gamer.reboot();
    }
}
