//Es gibt 4 verschiedene Arten von Cards.DamageCards
public abstract class DamageCards extends Cards {

    public String getCardName () {
       // Cards card = programmingCardDeck.remove(0);
       // return card.getName();
        return null;
    }
}

