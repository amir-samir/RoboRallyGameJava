import org.junit.Test;

public class TimerTest {

    @Test
    public void timerTest(){

        //game.OurTimer ourTimer = new game.OurTimer(30);

    }
}
